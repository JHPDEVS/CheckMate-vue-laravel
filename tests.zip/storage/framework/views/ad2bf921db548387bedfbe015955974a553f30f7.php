<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
        <?php if(Auth::check()): ?> 
        <meta name="user-name" content="<?php echo e(Auth::user()->name); ?>">
        <meta name="user-sid" content="<?php echo e(Auth::user()->sid); ?>">
        <meta name="user-class" content="<?php echo e(Auth::user()->class); ?>">
        <meta name="user-photo" content="<?php echo e(Auth::user()->profile_photo_path); ?>">
        <meta name="user-id" content="<?php echo e(Auth::user()->id); ?>">
        <meta name="user-current_team_id" content="<?php echo e(Auth::user()->current_team_id); ?>">
        <?php endif; ?> 
        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
        <!-- Scripts -->
        <?php echo app('Tightenco\Ziggy\BladeRouteGenerator')->generate(); ?>
        <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
        <script src="<?php echo e(asset('js/jquery-3.6.0.min.js')); ?>" defer></script>
    </head>
    <body class="font-sans antialiased">
        <div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div>

        
    </body>
</html>
<?php /**PATH C:\Users\박주형\checkmate\resources\views/app.blade.php ENDPATH**/ ?>