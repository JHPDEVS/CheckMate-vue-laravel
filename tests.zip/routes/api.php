<?php

use App\Http\Controllers\AttendsController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SocialController;
use App\Http\Controllers\TimetablesController;
use App\Http\Controllers\UsersController;
use Inertia\Inertia;
use App\Http\Controllers\Attend_postsController;
use App\Http\Controllers\RunsController;
use App\Models\Attend_posts;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

// axios.Post('/api/attends') <- 요청 방법
Route::post('/attends', [AttendsController::class, 'attend']);

Route::post('/absence', [AttendsController::class, 'absent']);

Route::get('/attends/not_users', [AttendsController::class, 'notAttendUsers']);

Route::get('/timetables', [TimetablesController::class, 'getTimetables']);



// 관리자 페이지, 유저 수정 관련
Route::get('/users', [UsersController::class, 'read']);
Route::patch('/user/{selected_user_id}', [UsersController::class, 'update']);

// 랭크 관련 (나중에 해당년도 별로 뽑아오기로 수정??)
Route::get('/users/runners', [UsersController::class, 'theMostestRunner']);
Route::get('/users/absentees', [UsersController::class, 'theMostestAbsentee']);
Route::get('/users/latecomers', [UsersController::class, 'theMostestLatecomer']);
Route::get('/users/rank', [UsersController::class, 'getUsersAttendsByDate']);
Route::get('/user/attendStatusByMonth', [AttendsController::class, 'getAttendStatusByMonth']);
// 출결 현황
Route::get('/user/attendance/{user_id}', [UsersController::class, 'getAttendanceStatus']);
Route::get('/user/attendStatus/{user_id}', [UsersController::class, 'getUserStatus']);

// run 달리면
Route::patch('/run/{selected_user_id}', [RunsController::class, 'minusRun']);

//Attend_posts 달리기 인증 게시판
Route::post('/attend_posts/create', [Attend_postsController::class, 'create']);
Route::get('/attend_posts/index', [Attend_postsController::class, 'index']);
Route::get('/attend_posts/{selected_post_id}', [Attend_postsController::class, 'show']);
Route::put('/attend_posts/{selected_post_id}', [Attend_postsController::class, 'update']);
Route::delete('/attend_posts/{selected_post_id}', [Attend_postsController::class, 'destroy']);